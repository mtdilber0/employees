const mongoose = require("mongoose")

const employeeSchema = mongoose.Schema({
    name:{
        type: String,
        required: [true, "please add name"]
    },
    role:{
        type: String,
        required: [true, "please add role"]
    },
    salary:{
        type: Number,
        required: [true, "please add salary"]
    }
},
{
    timestamps: true
}
)

module.exports = mongoose.model("Employee",employeeSchema)