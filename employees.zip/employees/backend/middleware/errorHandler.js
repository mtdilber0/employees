const {statusCodes} = require("../constants")
const errorHandler = (err,req,res,next) => {
    const statusCode = res.statusCode ? res.statusCode : 500
    switch (statusCode) {
        case statusCodes.VALIDATION_ERROR:
            res.json({title: "Validation error",message: err.message, stackTrace: err.stack})        
            break;
        case statusCodes.NOT_FOUND:
            res.json({title: "Not Found",message: err.message, stackTrace: err.stack})        
            break;
        case statusCodes.INTERNAL_SERVER_ERROR:
            res.json({title: "Internal server error",message: err.message, stackTrace: err.stack})        
            break;
        default:
            break;
    }
    
}

module.exports = errorHandler