
const Employee = require("../models/employeeModel")


const getAllEmployees = async(req,res,next)=>{
    try {
        const employees = await Employee.find()
        res.status(200).json(employees)
    } catch (error) {
        next(error)
    }
}

const getEmployee = async(req,res,next)=>{
    try {
        console.log("inside get employee")
        const employee = await Employee.findById(req.params.id)
        console.log(employee)
        if(!employee){
            res.status(404)
            throw new Error("Employe not found")
        }
        res.status(200).json(employee)
    } catch (error) {
        next(error)
    }
    
}

const createEmployee = async(req,res,next)=>{
    console.log("req body",req.body)
    try {
        const {name,role,salary} = req.body
        if(!name || !role){
            res.status(400)
            throw new Error("All fields are mandatory")
        }
        const employee = await Employee.create({name,role,salary})
        res.status(201).json(employee)
    } catch (error) {
        next(error)
    }
    
}

const updateEmployee = async(req,res,next)=>{
    try {
        res.status(200).json({message:`update employee ${req.params.id}`})
    } catch (error) {
        next(error)
    }
}

const deleteEmployee = async(req,res)=>{
    res.status(200).json({message:`delete employee ${req.params.id}`})
}

module.exports = {getAllEmployees,getEmployee,createEmployee,updateEmployee,deleteEmployee}