const express = require("express")
const errorHandler = require("./middleware/errorHandler")
const connectDb = require("./config/dbConnection")
const dotenv = require("dotenv").config()

// connect to mongodb
connectDb()

const app = express()

// middleware for parsing the incoming request body
app.use(express.json())

// middleware to use the path "api/employees" for all requests
app.use("/api/employees",require("./routes/adminRoutes")) 

// middleware to handle errors
app.use(errorHandler)

const port = process.env.PORT

app.listen(port,()=>{
    console.log("server running on",port)
})