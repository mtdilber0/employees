import axios from "axios";
const LoginForm = ({
  loginForm,
  setLoginForm,
  isAdmin,
  setIsAdmin,
  loggedIn,
  setLoggedIn,
}) => {
  const updateLoginForm = (e) => {
    const { name, value } = e.target;
    setLoginForm({ ...loginForm, [name]: value });
  };
  const login = async (e) => {
    e.preventDefault();

    const resp = await axios.post("/login", loginForm, {
      withCredentials: true,
    });
    console.log("response of login", resp);
    if (resp.status == 200) {
      // set log in state
      setLoggedIn(true);
      console.log("logged in state", loggedIn);
      // set admin state
      setIsAdmin(resp.data.isAdmin);
    }
  };
  return (
    <div>
      <h2>Login page</h2>
      <form onSubmit={login}>
        <input
          type="text"
          name="email"
          value={loginForm.email}
          placeholder="email"
          onChange={updateLoginForm}
        />
        <input
          type="password"
          name="password"
          value={loginForm.password}
          placeholder="password"
          onChange={updateLoginForm}
        />
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default LoginForm;
