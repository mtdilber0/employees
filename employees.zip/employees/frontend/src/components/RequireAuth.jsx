import axios from "axios";
import { useEffect } from "react";
const RequireAuth = (props) => {
  console.log("require auth logged in", props);
  const { loggedIn, setLoggedIn } = props.children.props;
  const checkAuth = async () => {
    try {
      const resp = await axios.get("/checkauth", { withCredentials: true });
      console.log("resp", resp);
      setLoggedIn(true);
    } catch (error) {
      console.log("error", error);
      setLoggedIn(false);
    }
  };
  useEffect(async () => {
    if (loggedIn === null) {
      await checkAuth();
    }
  }, []);
    if (!loggedIn) {
      return (
        <div>
          <h2>Please Login</h2>
        </div>
      );
    }
  return <div>{props.children}</div>;
};

export default RequireAuth;
